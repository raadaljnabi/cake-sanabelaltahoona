package com.cakeshow.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.content.ContentValues;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import java.io.OutputStream;
import android.widget.FrameLayout;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebResourceRequest;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    private static final int PICK_REQ = 1001;
    private WebView web;
    private ValueCallback<Uri[]> fileCb;
    private WebView printView; // kept alive until printing finishes
    private WebView shareView; // for converting the receipt to PDF
    private FrameLayout root;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        // Keep the screen on (display mode in the shop)
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        // Needed to capture the whole receipt as an image
        if (Build.VERSION.SDK_INT >= 21) WebView.enableSlowWholeDocumentDraw();
        root = new FrameLayout(this);
        web = new WebView(this);
        web.setBackgroundColor(0xFFF8EBCF);
        root.addView(web, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);   // localStorage to save the data
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setTextZoom(100);             // ignore the device font size so the layout stays the same
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);

        web.setWebViewClient(new WebViewClient() {
            // Links like WhatsApp open outside the app
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                return openExternal(req.getUrl());
            }
            @SuppressWarnings("deprecation")
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return openExternal(Uri.parse(url));
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb,
                                             FileChooserParams params) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                // Images by default, any file for restoring a backup
                boolean any = false;
                String[] acc = params.getAcceptTypes();
                if (acc != null) for (String t : acc) if (t != null && (t.contains("json") || t.equals("*/*"))) any = true;
                i.setType(any ? "*/*" : "image/*");
                if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                }
                try {
                    startActivityForResult(Intent.createChooser(i, "اختر الصور"), PICK_REQ);
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }
        });

        // Print the receipt from inside the page: Android.printHtml(html)
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void printHtml(final String html) {
                runOnUiThread(new Runnable() {
                    @Override public void run() { printReceipt(html); }
                });
            }

            // Save the backup in Downloads or share it
            @JavascriptInterface
            public void saveFile(final String data, final String name, final boolean share) {
                runOnUiThread(new Runnable() {
                    @Override public void run() { saveBackup(data, name, share); }
                });
            }

            // Send the receipt as a PDF straight to the customer's WhatsApp
            @JavascriptInterface
            public void sharePdf(final String html, final String phone, final String no, final String caption) {
                runOnUiThread(new Runnable() {
                    @Override public void run() { makePdf(html, phone, no, caption); }
                });
            }
        }, "Android");

        if (state != null) web.restoreState(state);
        else web.loadUrl("file:///android_asset/index.html");

        hideBars();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != PICK_REQ || fileCb == null) return;
        Uri[] result = null;
        if (res == RESULT_OK && data != null) {
            ClipData clip = data.getClipData();
            if (clip != null) {
                result = new Uri[clip.getItemCount()];
                for (int k = 0; k < clip.getItemCount(); k++) result[k] = clip.getItemAt(k).getUri();
            } else if (data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
        }
        fileCb.onReceiveValue(result);
        fileCb = null;
    }

    private void printReceipt(String html) {
        final WebView pv = new WebView(this);
        printView = pv;
        pv.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                if (pm == null) return;
                PrintDocumentAdapter ad = view.createPrintDocumentAdapter("receipt");
                pm.print("وصل سنابل الطاحونة", ad, new PrintAttributes.Builder().build());
            }
        });
        pv.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
    }

    private void saveBackup(String data, String name, boolean share) {
        try {
            byte[] bytes = data.getBytes("UTF-8");
            if (!share && Build.VERSION.SDK_INT >= 29) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
                cv.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SanabelBackup");
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (u != null) {
                    OutputStream os = getContentResolver().openOutputStream(u);
                    os.write(bytes);
                    os.close();
                    Toast.makeText(this, "تم الحفظ بمجلد التنزيلات / SanabelBackup", Toast.LENGTH_LONG).show();
                    return;
                }
            }
            // Share (Drive, Telegram, WhatsApp...) or older Android versions
            File dir = new File(getCacheDir(), "receipts");
            dir.mkdirs();
            File f = new File(dir, name);
            FileOutputStream out = new FileOutputStream(f);
            out.write(bytes);
            out.close();
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("application/json");
            i.putExtra(Intent.EXTRA_STREAM, Uri.parse("content://" + ReceiptProvider.AUTH + "/" + name));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, "حفظ النسخة الاحتياطية"));
        } catch (Exception e) {
            Toast.makeText(this, "تعذر حفظ النسخة الاحتياطية", Toast.LENGTH_LONG).show();
        }
    }

    private void makePdf(String html, final String phone, final String no, final String caption) {
        final float dens = getResources().getDisplayMetrics().density;
        final int w = (int) (400 * dens);
        if (shareView != null) { root.removeView(shareView); shareView.destroy(); }
        final WebView sv = new WebView(this);
        shareView = sv;
        sv.setBackgroundColor(Color.WHITE);
        // Placed behind the main screen so it stays hidden
        root.addView(sv, 0, new FrameLayout.LayoutParams(w, (int) (900 * dens)));
        Toast.makeText(this, "جاري تجهيز الوصل...", Toast.LENGTH_SHORT).show();
        sv.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(final WebView view, String url) {
                view.postDelayed(new Runnable() {
                    @Override public void run() {
                        int h = (int) (view.getContentHeight() * dens);
                        if (h < 200) h = (int) (900 * dens);
                        final int fh = h;
                        view.setLayoutParams(new FrameLayout.LayoutParams(w, fh));
                        view.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                                View.MeasureSpec.makeMeasureSpec(fh, View.MeasureSpec.EXACTLY));
                        view.layout(0, 0, w, fh);
                        view.postDelayed(new Runnable() {
                            @Override public void run() { capture(view, w, fh, phone, no, caption); }
                        }, 400);
                    }
                }, 400);
            }
        });
        sv.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
    }

    private void capture(WebView view, int w, int h, String phone, String no, String caption) {
        try {
            Bitmap bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(bm);
            c.drawColor(Color.WHITE);
            view.draw(c);

            float pw = 320f, sc = pw / w;
            PdfDocument doc = new PdfDocument();
            PdfDocument.Page pg = doc.startPage(new PdfDocument.PageInfo.Builder((int) pw, (int) (h * sc), 1).create());
            Canvas pc = pg.getCanvas();
            pc.scale(sc, sc);
            pc.drawBitmap(bm, 0, 0, null);
            doc.finishPage(pg);

            File dir = new File(getCacheDir(), "receipts");
            dir.mkdirs();
            String name = "receipt-" + no.replaceAll("[^0-9]", "") + ".pdf";
            File f = new File(dir, name);
            FileOutputStream out = new FileOutputStream(f);
            doc.writeTo(out);
            out.close();
            doc.close();
            bm.recycle();

            root.removeView(view);
            view.destroy();
            shareView = null;
            sendPdf(Uri.parse("content://" + ReceiptProvider.AUTH + "/" + name), phone, caption);
        } catch (Exception e) {
            Toast.makeText(this, "تعذر إنشاء ملف PDF", Toast.LENGTH_LONG).show();
        }
    }

    private Intent pdfIntent(Uri u, String caption) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("application/pdf");
        i.putExtra(Intent.EXTRA_STREAM, u);
        if (caption != null && caption.length() > 0) i.putExtra(Intent.EXTRA_TEXT, caption);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        return i;
    }

    private void sendPdf(Uri u, String phone, String caption) {
        // Straight to the customer's chat on WhatsApp, then WhatsApp Business, otherwise the share list
        String[] apps = {"com.whatsapp", "com.whatsapp.w4b"};
        for (String app : apps) {
            try {
                Intent i = pdfIntent(u, caption);
                i.setPackage(app);
                if (phone != null && phone.length() > 6) i.putExtra("jid", phone + "@s.whatsapp.net");
                startActivity(i);
                return;
            } catch (Exception e) { /* try the next one */ }
        }
        try {
            startActivity(Intent.createChooser(pdfIntent(u, caption), "إرسال الوصل"));
        } catch (Exception e) {
            Toast.makeText(this, "ما لكيت تطبيق للإرسال", Toast.LENGTH_LONG).show();
        }
    }

    private boolean openExternal(Uri u) {
        if (u == null || "file".equals(u.getScheme())) return false;
        try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception e) { }
        return true;
    }

    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
